fetch("/api/hotels")
  .then(res => res.json())
  .then(data => {
      const select = document.getElementById("hotelSelect");
      data.forEach(h => {
          const opt = document.createElement("option");
          opt.value = h.id;
          opt.text = `${h.name} - ${h.location}`;
          select.appendChild(opt);
      });
  });
