fetch("/api/dashboard/counts")
    .then(response => response.json())
    .then(data => {
        document.getElementById("totalBookings").innerText = data.bookings;
        document.getElementById("totalPackages").innerText = data.packages;
        document.getElementById("totalHotels").innerText = data.hotels;
        document.getElementById("totalUsers").innerText = data.users;
    })
    .catch(error => console.error("Error loading dashboard data:", error));
