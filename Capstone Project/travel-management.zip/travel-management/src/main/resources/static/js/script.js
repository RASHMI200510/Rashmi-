document.addEventListener("DOMContentLoaded", function () {

    console.log("script.js loaded");

    fetch("/api/user-role")
        .then(res => res.text())
        .then(role => {
            console.log("User role:", role);
            document.getElementById("userRole").value = role;
            loadPackages(role);
        })
        .catch(err => console.error("Role fetch error:", err));
});

function loadPackages(role) {

    fetch("/api/packages")
        .then(response => response.json())
        .then(data => {

            const table = document.getElementById("packageTable");
            table.innerHTML = "";

            data.forEach(p => {

                let actionBtn = "";

                if (role === "ADMIN") {
                    actionBtn = `
                        <a href="/deletePackage?id=${p.id}"
                           onclick="return confirm('Delete this package?')"
                           class="btn-action btn-delete">
                           Delete
                        </a>`;
                }
                else if (role === "USER") {
                    actionBtn = `
                        <a href="/bookPackage?packageId=${p.id}"
                           class="btn-action btn-book">
                           Book
                        </a>`;
                }
                else {
                    actionBtn = `
                        <a href="/login.html" class="btn-action btn-login">
                            Login
                        </a>`;
                }

                table.innerHTML += `
                    <tr>
                        <td>${p.id}</td>
                        <td>${p.destination}</td>
                        <td>${p.price}</td>
                        <td>${p.days}</td>
                        <td>${p.description}</td>
                        <td>${actionBtn}</td>
                    </tr>
                `;
            });
        })
        .catch(err => console.error("Package load error:", err));
}
