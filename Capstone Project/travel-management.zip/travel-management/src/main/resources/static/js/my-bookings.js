document.addEventListener("DOMContentLoaded", function () {

    fetch("/api/my-bookings")
        .then(response => response.json())
        .then(data => {

            let table = document.getElementById("bookingTable");
            table.innerHTML = "";

            if (data.length === 0) {
                table.innerHTML = "<tr><td colspan='5'>No bookings found</td></tr>";
                return;
            }

            data.forEach(b => {
                table.innerHTML += `
                    <tr>
                        <td>${b.destination}</td>
                        <td>${b.days}</td>
                        <td>${b.price}</td>
                        <td>${b.bookingDate}</td>
                        <td>${b.status}</td>
                    </tr>
                `;
            });
        })
        .catch(err => console.error("Error loading bookings:", err));
});
