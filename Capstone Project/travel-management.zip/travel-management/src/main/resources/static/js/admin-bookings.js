fetch("/api/admin/bookings")
.then(res => res.json())
.then(data => {

    let table = document.getElementById("bookingTable");
    table.innerHTML = "";

    data.forEach(b => {
        table.innerHTML += `
            <tr>
                <td>${b.userEmail}</td>
                <td>${b.destination}</td>
                <td>${b.days}</td>
                <td>${b.price}</td>
                <td>${b.bookingDate}</td>
                <td>${b.status}</td>
                <td>
                    <form action="/admin/update-booking" method="post">
                        <input type="hidden" name="id" value="${b.id}">
                        <select name="status">
                            <option>BOOKED</option>
                            <option>CONFIRMED</option>
                            <option>CANCELLED</option>
                        </select>
                        <button type="submit">Update</button>
                    </form>
                </td>
            </tr>
        `;
    });
});
