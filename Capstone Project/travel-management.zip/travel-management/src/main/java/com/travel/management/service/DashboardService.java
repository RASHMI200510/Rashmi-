package com.travel.management.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.travel.management.dao.DashboardDAO;

@Service
public class DashboardService {

    @Autowired
    private DashboardDAO dashboardDAO;

    public int getTotalUsers() throws Exception {
        return dashboardDAO.totalUsers();
    }

    public int getTotalPackages() throws Exception {
        return dashboardDAO.totalPackages();
    }

    public int getTotalHotels() throws Exception {
        return dashboardDAO.totalHotels();
    }

    public int getTotalBookings() throws Exception {
        return dashboardDAO.totalBookings();
    }
}

