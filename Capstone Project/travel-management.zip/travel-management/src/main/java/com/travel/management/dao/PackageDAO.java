package com.travel.management.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.travel.management.model.TravelPackage;

@Repository
public class PackageDAO {

    @Autowired
    private DataSource dataSource;

    // ✅ ADD PACKAGE WITH HOTEL
    public void addPackage(TravelPackage p) throws Exception {

        Connection con = dataSource.getConnection();

        String sql = """
            INSERT INTO travel_package
            (destination, price, days, description, hotel_id)
            VALUES (?, ?, ?, ?, ?)
        """;

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, p.getDestination());
        ps.setDouble(2, p.getPrice());
        ps.setInt(3, p.getDays());
        ps.setString(4, p.getDescription());
        ps.setInt(5, p.getHotelId());

        ps.executeUpdate();
        con.close();
    }

    // ✅ GET ALL PACKAGES WITH HOTEL INFO
    public List<TravelPackage> getAllPackages() throws Exception {

        List<TravelPackage> list = new ArrayList<>();
        Connection con = dataSource.getConnection();

        String sql = """
            SELECT 
                p.id, p.destination, p.price, p.days, p.description,
                h.id AS hotel_id, h.name AS hotel_name, h.location AS hotel_location
            FROM travel_package p
            LEFT JOIN hotels h ON p.hotel_id = h.id
        """;

        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            TravelPackage p = new TravelPackage();
            p.setId(rs.getInt("id"));
            p.setDestination(rs.getString("destination"));
            p.setPrice(rs.getDouble("price"));
            p.setDays(rs.getInt("days"));
            p.setDescription(rs.getString("description"));

            p.setHotelId(rs.getInt("hotel_id"));
            p.setHotelName(rs.getString("hotel_name"));
            p.setHotelLocation(rs.getString("hotel_location"));

            list.add(p);
        }

        con.close();
        return list;
    }

    // ✅ DELETE PACKAGE
    public void deletePackage(int id) throws Exception {

        Connection con = dataSource.getConnection();

        String sql = "DELETE FROM travel_package WHERE id=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setInt(1, id);

        ps.executeUpdate();
        con.close();
    }
}
