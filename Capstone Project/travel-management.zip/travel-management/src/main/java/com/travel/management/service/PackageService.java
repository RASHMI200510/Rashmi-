package com.travel.management.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.travel.management.dao.PackageDAO;
import com.travel.management.model.TravelPackage;

@Service
public class PackageService {

    @Autowired
    private PackageDAO packageDAO;

    public void savePackage(TravelPackage p) throws Exception {
        packageDAO.addPackage(p);
    }
        
        public List<TravelPackage> getAllPackages() throws Exception {
            return packageDAO.getAllPackages();
    }
        public void deletePackage(int id) throws Exception {
            packageDAO.deletePackage(id);
        }

}
