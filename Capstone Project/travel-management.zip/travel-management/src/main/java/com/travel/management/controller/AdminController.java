package com.travel.management.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.travel.management.service.AdminService;

@RestController
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    // ✅ DASHBOARD COUNTS API
    @GetMapping("/dashboard-counts")
    public Map<String, Integer> getDashboardCounts() {

        Map<String, Integer> counts = new HashMap<>();

        counts.put("totalBookings", adminService.getTotalBookings());
        counts.put("totalPackages", adminService.getTotalPackages());
        counts.put("totalHotels", adminService.getTotalHotels());
        counts.put("totalUsers", adminService.getTotalUsers());

        return counts;
    }
}
