package com.travel.management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.travel.management.model.TravelPackage;
import com.travel.management.service.PackageService;

@Controller
public class PackageController {

    @Autowired
    private PackageService packageService;

    // ✅ ADD PACKAGE (ADMIN)
    @PostMapping("/addPackage")
    public String addPackage(TravelPackage p) throws Exception {
        packageService.savePackage(p);
        return "redirect:/add-package.html";
    }

    // ✅ VIEW PACKAGES (API)
    @GetMapping("/api/packages")
    @ResponseBody
    public List<TravelPackage> getPackagesApi() throws Exception {
        return packageService.getAllPackages();
    }

    // ✅ DELETE PACKAGE (ADMIN)
    @GetMapping("/deletePackage")
    public String deletePackage(@RequestParam int id) throws Exception {
        packageService.deletePackage(id);
        return "redirect:/view-packages.html";
    }
}
       