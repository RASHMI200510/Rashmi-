package com.travel.management.controller;

import com.travel.management.model.User;
import jakarta.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class AuthController {

    // 🔐 ADMIN DASHBOARD PROTECTION
    @GetMapping("/admin-dashboard")
    public String adminDashboard(HttpSession session) {

        User user = (User) session.getAttribute("loggedInUser");

        if (user == null || !"ADMIN".equalsIgnoreCase(user.getRole())) {
            return "redirect:/login.html";
        }

        return "redirect:/admin-dashboard.html";
    }

    // 🔐 USER DASHBOARD PROTECTION
    @GetMapping("/user-dashboard")
    public String userDashboard(HttpSession session) {

        User user = (User) session.getAttribute("loggedInUser");

        if (user == null || !"USER".equalsIgnoreCase(user.getRole())) {
            return "redirect:/login.html";
        }

        return "redirect:/user-dashboard.html";
    }

    // 🔥 ROLE API FOR FRONTEND (ADMIN / USER / GUEST)
    @GetMapping("/api/user-role")
    @ResponseBody
    public String getUserRole(HttpSession session) {

        Object obj = session.getAttribute("loggedInUser");

        if (obj == null) {
            return "GUEST";
        }

        User user = (User) obj;
        return user.getRole(); // ADMIN or USER
    }
}
