package com.travel.management.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.travel.management.dao.HotelDAO;
import com.travel.management.model.Hotel;

@Service
public class HotelService {

    @Autowired
    private HotelDAO hotelDAO;

    // ADD HOTEL
    public void addHotel(Hotel hotel) throws Exception {
        hotelDAO.addHotel(hotel);
    }

    // GET ALL HOTELS
    public List<Hotel> getAllHotels() throws Exception {
        return hotelDAO.getAllHotels();
    }
}
