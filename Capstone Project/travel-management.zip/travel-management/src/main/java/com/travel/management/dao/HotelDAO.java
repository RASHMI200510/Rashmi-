package com.travel.management.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.travel.management.model.Hotel;

@Repository
public class HotelDAO {

    @Autowired
    private DataSource dataSource;

    // ✅ ADD HOTEL
    public void addHotel(Hotel hotel) throws Exception {

        Connection con = dataSource.getConnection();

        String sql = "INSERT INTO hotels(name, location, price_per_day) VALUES (?, ?, ?)";
        PreparedStatement ps = con.prepareStatement(sql);

        ps.setString(1, hotel.getName());
        ps.setString(2, hotel.getLocation());
        ps.setDouble(3, hotel.getPricePerDay());

        ps.executeUpdate();

        ps.close();
        con.close();
    }

    // ✅ GET ALL HOTELS (FOR DROPDOWN)
    public List<Hotel> getAllHotels() throws Exception {

        List<Hotel> list = new ArrayList<>();
        Connection con = dataSource.getConnection();

        String sql = "SELECT id, name, location, price_per_day FROM hotels";
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Hotel h = new Hotel();
            h.setId(rs.getInt("id"));
            h.setName(rs.getString("name"));
            h.setLocation(rs.getString("location"));
            h.setPricePerDay(rs.getDouble("price_per_day"));
            list.add(h);
        }

        rs.close();
        ps.close();
        con.close();

        return list;
    }
}

