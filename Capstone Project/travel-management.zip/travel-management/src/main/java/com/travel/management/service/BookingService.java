package com.travel.management.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.travel.management.dao.BookingDAO;
import com.travel.management.model.Booking;

@Service
public class BookingService {

    @Autowired
    private BookingDAO bookingDAO;

    // USER books a package
    public void bookPackage(String email, int packageId) throws Exception {
        bookingDAO.bookPackage(email, packageId);
    }

    // USER views own bookings
    public List<Booking> getBookingsByUser(String email) throws Exception {
        return bookingDAO.getBookingsByUser(email);
    }

    // ADMIN views all bookings
    public List<Booking> getAllBookings() throws Exception {
        return bookingDAO.getAllBookings();
    }

    // ADMIN updates booking status
    public void updateStatus(int bookingId, String status) throws Exception {
        bookingDAO.updateStatus(bookingId, status);
    }
    
    public List<Booking> getPendingBookings() throws Exception {
        return bookingDAO.getPendingBookings();
    }

}
