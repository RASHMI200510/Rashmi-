package com.travel.management.controller;

import com.travel.management.model.User;
import com.travel.management.service.UserService;
import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class LoginController {

    @Autowired
    private UserService userService;

    // ✅ HANDLE GET (PREVENT 405)
    @GetMapping("/doLogin")
    public String handleLoginGet() {
        return "redirect:/login.html";
    }

    // ✅ HANDLE POST (ACTUAL LOGIN)
    @PostMapping("/doLogin")
    public String doLogin(
            @RequestParam String email,
            @RequestParam String password,
            HttpSession session) throws Exception {

        User user = userService.login(email, password);

        if (user == null) {
            return "redirect:/login.html?error=true";
        }

        session.setAttribute("loggedInUser", user);
        session.setAttribute("userEmail", user.getEmail());
        session.setAttribute("userRole", user.getRole());

        if ("ADMIN".equalsIgnoreCase(user.getRole())) {
            return "redirect:/admin-dashboard.html";
        } else {
            return "redirect:/user-dashboard.html";
        }
    }

    // ✅ LOGOUT
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login.html";
    }
}

    
    
  


