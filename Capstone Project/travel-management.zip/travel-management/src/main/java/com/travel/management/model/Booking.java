package com.travel.management.model;

public class Booking {

    private int id;
    private String userEmail;
    private int packageId;
    private String bookingDate;
    private String status;

    // 🔹 EXTRA FIELDS FOR DISPLAY (JOIN RESULT)
    private String destination;
    private int days;
    private double price;
    private String hotelName;
    private String hotelLocation;


    // ===== getters & setters =====

    public int getId() { 
        return id; 
    }
    public void setId(int id) { 
        this.id = id; 
    }

    public String getUserEmail() { 
        return userEmail; 
    }
    public void setUserEmail(String userEmail) { 
        this.userEmail = userEmail; 
    }

    public int getPackageId() { 
        return packageId; 
    }
    public void setPackageId(int packageId) { 
        this.packageId = packageId; 
    }

    public String getBookingDate() { 
        return bookingDate; 
    }
    public void setBookingDate(String bookingDate) { 
        this.bookingDate = bookingDate; 
    }

    public String getStatus() { 
        return status; 
    }
    public void setStatus(String status) { 
        this.status = status; 
    }

    public String getDestination() {
        return destination;
    }
    public void setDestination(String destination) {
        this.destination = destination;
    }

    public int getDays() {
        return days;
    }
    public void setDays(int days) {
        this.days = days;
    }

    public double getPrice() {
        return price;
    }
    public void setPrice(double price) {
        this.price = price;
    }
    
    public String getHotelName() {
        return hotelName;
    }

    public void setHotelName(String hotelName) {
        this.hotelName = hotelName;
    }

    public String getHotelLocation() {
        return hotelLocation;
    }

    public void setHotelLocation(String hotelLocation) {
        this.hotelLocation = hotelLocation;
    }

}
