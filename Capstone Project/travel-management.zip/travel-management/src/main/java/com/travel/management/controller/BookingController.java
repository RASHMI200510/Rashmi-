package com.travel.management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.travel.management.model.Booking;
import com.travel.management.model.User;
import com.travel.management.service.BookingService;

import jakarta.servlet.http.HttpSession;

@Controller
public class BookingController {

    @Autowired
    private BookingService bookingService;

    // 🔐 ADMIN: View all bookings
    @GetMapping("/bookPackage")
    public String bookPackage(@RequestParam int packageId,
                              HttpSession session) throws Exception {

        User user = (User) session.getAttribute("loggedInUser");
        if (user == null) {
            return "redirect:/login.html";
        }

        bookingService.bookPackage(user.getEmail(), packageId);
        return "redirect:/my-bookings.html?success=true";

    }

    // 🔐 ADMIN: Approve / Cancel booking
    @PostMapping("/admin/update-booking")
    public String updateBooking(
            @RequestParam int id,
            @RequestParam String status,
            HttpSession session) throws Exception {

        User user = (User) session.getAttribute("loggedInUser");

        if (user == null || !"ADMIN".equalsIgnoreCase(user.getRole())) {
            return "redirect:/login.html";
        }

        bookingService.updateStatus(id, status);
        return "redirect:/admin-bookings.html";
    }
    
 // 🔐 USER: Cancel own booking
    @PostMapping("/user/cancel-booking")
    public String cancelBooking(@RequestParam int id, HttpSession session) throws Exception {

        User user = (User) session.getAttribute("loggedInUser");

        if (user == null || !"USER".equalsIgnoreCase(user.getRole())) {
            return "redirect:/login.html";
        }

        bookingService.updateStatus(id, "CANCELLED");
        return "redirect:/my-bookings.html";
    }
    
    @GetMapping("/api/my-bookings")
    @ResponseBody
    public List<Booking> myBookings(HttpSession session) throws Exception {

        User user = (User) session.getAttribute("loggedInUser");

        if (user == null) {
            return List.of(); // not logged in
        }

        return bookingService.getBookingsByUser(user.getEmail());
    }

    @GetMapping("/api/admin/pending-bookings")
    @ResponseBody
    public List<Booking> pendingBookings(HttpSession session) throws Exception {

        User user = (User) session.getAttribute("loggedInUser");

        if (user == null || !"ADMIN".equalsIgnoreCase(user.getRole())) {
            return List.of();
        }

        return bookingService.getPendingBookings();
    }

    @GetMapping("/api/admin/bookings")
    @ResponseBody
    public List<Booking> getAllBookings(HttpSession session) throws Exception {

        User user = (User) session.getAttribute("loggedInUser");

        if (user == null || !"ADMIN".equalsIgnoreCase(user.getRole())) {
            return List.of();
        }

        return bookingService.getAllBookings();
    }


}

