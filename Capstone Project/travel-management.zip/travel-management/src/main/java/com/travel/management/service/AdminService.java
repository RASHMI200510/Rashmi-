package com.travel.management.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.travel.management.dao.AdminDAO;

@Service
public class AdminService {

    @Autowired
    private AdminDAO adminDAO;

    public int getTotalBookings() {
        return adminDAO.countBookings();
    }

    public int getTotalPackages() {
        return adminDAO.countPackages();
    }

    public int getTotalHotels() {
        return adminDAO.countHotels();
    }

    public int getTotalUsers() {
        return adminDAO.countUsers();
    }
}
