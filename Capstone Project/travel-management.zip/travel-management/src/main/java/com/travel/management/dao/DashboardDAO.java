package com.travel.management.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class DashboardDAO {

    @Autowired
    private DataSource dataSource;

    private int getCount(String sql) throws Exception {
        Connection con = dataSource.getConnection();
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        rs.next();
        int count = rs.getInt(1);
        rs.close();
        ps.close();
        con.close();
        return count;
    }

    public int totalUsers() throws Exception {
        return getCount("SELECT COUNT(*) FROM users");
    }

    public int totalPackages() throws Exception {
        return getCount("SELECT COUNT(*) FROM travel_package");
    }

    public int totalHotels() throws Exception {
        return getCount("SELECT COUNT(*) FROM hotels");
    }

    public int totalBookings() throws Exception {
        return getCount("SELECT COUNT(*) FROM bookings");
    }
}

