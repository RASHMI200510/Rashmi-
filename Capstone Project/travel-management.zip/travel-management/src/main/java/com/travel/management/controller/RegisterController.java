package com.travel.management.controller;

import com.travel.management.model.User;
import com.travel.management.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class RegisterController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public String register(
            @RequestParam String name,
            @RequestParam String email,
            @RequestParam String password) {

        try {
            User user = new User();
            user.setName(name);
            user.setEmail(email);
            user.setPassword(password);
            user.setRole("USER");

            userService.register(user);
            return "redirect:/login.html?registered=true";

        } catch (RuntimeException e) {
            if ("EMAIL_EXISTS".equals(e.getMessage())) {
                return "redirect:/register.html?error=exists";
            }
            return "redirect:/register.html?error=true";
        } catch (Exception e) {
            return "redirect:/register.html?error=true";
        }
    }
}
