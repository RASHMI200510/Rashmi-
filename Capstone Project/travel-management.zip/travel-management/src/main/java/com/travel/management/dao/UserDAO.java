package com.travel.management.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.travel.management.model.User;

@Repository
public class UserDAO {

    @Autowired
    private DataSource dataSource;

    // ✅ NEW METHOD: Fetch user with role
    public User getUserByEmailAndPassword(String email, String password) throws Exception {

        Connection con = dataSource.getConnection();

        String sql = "SELECT * FROM users WHERE email=? AND password=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, email);
        ps.setString(2, password);
       

        ResultSet rs = ps.executeQuery();

        User user = null;

        if (rs.next()) {
            user = new User();
            user.setId(rs.getInt("id"));
            user.setName(rs.getString("name"));
            user.setEmail(rs.getString("email"));
            user.setPassword(rs.getString("password"));
            user.setRole(rs.getString("role")); // 🔥 IMPORTANT
        }

        con.close();
        return user;
    }
    
 // ============================
 // REGISTER NEW USER
 // ============================
    public void addUser(User user) throws Exception {

        Connection con = dataSource.getConnection();

        String sql = """
            INSERT INTO users (name, email, password, role)
            VALUES (?, ?, ?, ?)
        """;

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, user.getName());
        ps.setString(2, user.getEmail());
        ps.setString(3, user.getPassword());
        ps.setString(4, user.getRole());

        ps.executeUpdate();

        ps.close();
        con.close();
    }

    public boolean emailExists(String email) throws Exception {
        Connection con = dataSource.getConnection();

        String sql = "SELECT id FROM users WHERE email=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, email);

        ResultSet rs = ps.executeQuery();
        boolean exists = rs.next();

        con.close();
        return exists;
    }


}

