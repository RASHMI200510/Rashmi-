package com.travel.management.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class AdminDAO {

    @Autowired
    private DataSource dataSource;

    private int count(String sql) {
        try (Connection con = dataSource.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) return rs.getInt(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int countBookings() {
        return count("SELECT COUNT(*) FROM bookings");
    }

    public int countPackages() {
        return count("SELECT COUNT(*) FROM travel_package");
    }

    public int countHotels() {
        return count("SELECT COUNT(*) FROM hotels");
    }

    public int countUsers() {
        return count("SELECT COUNT(*) FROM users");
    }
}
