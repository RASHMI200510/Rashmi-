package com.travel.management.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.travel.management.service.DashboardService;

@RestController
public class DashboardController {

    @Autowired
    private DashboardService dashboardService;

    @GetMapping("/api/dashboard/counts")
    public Map<String, Integer> getDashboardCounts() throws Exception {

        Map<String, Integer> counts = new HashMap<>();

        counts.put("users", dashboardService.getTotalUsers());
        counts.put("packages", dashboardService.getTotalPackages());
        counts.put("hotels", dashboardService.getTotalHotels());
        counts.put("bookings", dashboardService.getTotalBookings());

        return counts;
    }
}

