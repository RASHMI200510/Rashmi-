package com.travel.management.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.travel.management.model.Booking;

@Repository
public class BookingDAO {

    @Autowired
    private DataSource dataSource;

    // =========================
    // USER BOOK PACKAGE
    // =========================
    public void bookPackage(String email, int packageId) throws Exception {

        Connection con = dataSource.getConnection();

        String sql = """
            INSERT INTO bookings (user_email, package_id, booking_date, status)
            VALUES (?, ?, NOW(), 'BOOKED')
        """;

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, email);
        ps.setInt(2, packageId);

        ps.executeUpdate();
        con.close();
    }

    // =========================
    // USER: VIEW OWN BOOKINGS
    // =========================
    public List<Booking> getBookingsByUser(String email) throws Exception {

        List<Booking> list = new ArrayList<>();
        Connection con = dataSource.getConnection();

        String sql = """
            SELECT 
                b.id,
                b.booking_date,
                b.status,
                p.destination,
                p.days,
                p.price,
                h.name AS hotel_name,
                h.location AS hotel_location
            FROM bookings b
            JOIN travel_package p ON b.package_id = p.id
            LEFT JOIN hotels h ON p.hotel_id = h.id
            WHERE b.user_email = ?
        """;

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, email);

        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Booking b = new Booking();
            b.setId(rs.getInt("id"));
            b.setBookingDate(rs.getString("booking_date"));
            b.setStatus(rs.getString("status"));
            b.setDestination(rs.getString("destination"));
            b.setDays(rs.getInt("days"));
            b.setPrice(rs.getDouble("price"));
            b.setHotelName(rs.getString("hotel_name"));
            b.setHotelLocation(rs.getString("hotel_location"));

            list.add(b);
        }

        con.close();
        return list;
    }

    // =========================
    // ADMIN: VIEW ALL BOOKINGS
    // =========================
    public List<Booking> getAllBookings() throws Exception {

        List<Booking> list = new ArrayList<>();
        Connection con = dataSource.getConnection();

        String sql = """
            SELECT 
                b.id,
                b.user_email,
                b.booking_date,
                b.status,
                p.destination,
                p.days,
                p.price,
                h.name AS hotel_name,
                h.location AS hotel_location
            FROM bookings b
            JOIN travel_package p ON b.package_id = p.id
            LEFT JOIN hotels h ON p.hotel_id = h.id
        """;

        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Booking b = new Booking();
            b.setId(rs.getInt("id"));
            b.setUserEmail(rs.getString("user_email"));
            b.setBookingDate(rs.getString("booking_date"));
            b.setStatus(rs.getString("status"));
            b.setDestination(rs.getString("destination"));
            b.setDays(rs.getInt("days"));
            b.setPrice(rs.getDouble("price"));
            b.setHotelName(rs.getString("hotel_name"));
            b.setHotelLocation(rs.getString("hotel_location"));

            list.add(b);
        }

        con.close();
        return list;
    }

    // =========================
    // UPDATE STATUS
    // =========================
    public void updateStatus(int bookingId, String status) throws Exception {

        Connection con = dataSource.getConnection();

        String sql = "UPDATE bookings SET status=? WHERE id=?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, status);
        ps.setInt(2, bookingId);

        ps.executeUpdate();
        con.close();
    }
    
    public List<Booking> getPendingBookings() throws Exception {

        List<Booking> list = new ArrayList<>();
        Connection con = dataSource.getConnection();

        String sql = """
            SELECT 
                b.id,
                b.user_email,
                b.booking_date,
                b.status,
                p.destination,
                p.days,
                p.price,
                h.name AS hotel_name
            FROM bookings b
            JOIN travel_package p ON b.package_id = p.id
            LEFT JOIN hotels h ON p.hotel_id = h.id
            WHERE b.status = 'BOOKED'
        """;

        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            Booking b = new Booking();
            b.setId(rs.getInt("id"));
            b.setUserEmail(rs.getString("user_email"));
            b.setBookingDate(rs.getString("booking_date"));
            b.setStatus(rs.getString("status"));
            b.setDestination(rs.getString("destination"));
            b.setDays(rs.getInt("days"));
            b.setPrice(rs.getDouble("price"));
            b.setHotelName(rs.getString("hotel_name"));
            list.add(b);
        }

        con.close();
        return list;
    }

}
