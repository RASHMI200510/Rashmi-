package com.travel.management.service;

import com.travel.management.dao.UserDAO;
import com.travel.management.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserDAO userDAO;
    
    public void register(User user) throws Exception {

        if (userDAO.emailExists(user.getEmail())) {
            throw new RuntimeException("EMAIL_EXISTS");
        }

        userDAO.addUser(user);
        
    }

    // LOGIN (already working)
    public User login(String email, String password) throws Exception {
        return userDAO.getUserByEmailAndPassword(email, password);
    }

    
}

