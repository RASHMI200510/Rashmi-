package com.travel.management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.travel.management.model.Hotel;
import com.travel.management.service.HotelService;

@Controller
public class HotelController {

    @Autowired
    private HotelService hotelService;

    // ✅ ADD HOTEL (ADMIN)
    @PostMapping("/addHotel")
    public String addHotel(
            @RequestParam String name,
            @RequestParam String location,
            @RequestParam double pricePerDay) throws Exception {

        Hotel hotel = new Hotel();
        hotel.setName(name);
        hotel.setLocation(location);
        hotel.setPricePerDay(pricePerDay);

        hotelService.addHotel(hotel);

        return "redirect:/dashboard.html";
    }

    // ✅ FETCH HOTELS (FOR DROPDOWN)
    @GetMapping("/api/hotels")
    @ResponseBody
    public List<Hotel> getAllHotels() throws Exception {
        return hotelService.getAllHotels();
    }
}

