package com.travel.management;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.travel.management.model.User;
import com.travel.management.service.UserService;

@SpringBootTest
public class AdminServiceTest {

    @Autowired
    private UserService userService;

    // ✅ Simple admin login test
    @Test
    void testAdminLogin() throws Exception {
        User admin = userService.login("admin@gmail.com", "admin123");

        assertNotNull(admin);
        assertEquals("ADMIN", admin.getRole());
    }
}
